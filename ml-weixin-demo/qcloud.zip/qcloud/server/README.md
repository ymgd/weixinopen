剪刀石头布 Server 端代码
===========

使用 SocketIO 提供实时连接服务。