export interface User {
    uid: string;
    uname: string;
    uavatar: string;
}