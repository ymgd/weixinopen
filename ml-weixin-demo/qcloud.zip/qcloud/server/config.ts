﻿export const config = {
    rootPath: "/applet/websocket/socket.io"
}