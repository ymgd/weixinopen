const basePath =  '/applet/websocket';

module.exports = {

    /** 通讯域名 */
    host: 'www.qcloud.la',
    basePath: '/applet/websocket',
    socketPath: basePath + '/socket.io' 
    
}