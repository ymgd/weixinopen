"use strict";

App({
    onLaunch() {
    },
    onShow() {
    },
    onHide() {
    },
    globalData: {
        windowHeight: 507
    }
});