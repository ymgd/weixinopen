var WebSocketServer = require('ws').Server,
ws = new WebSocketServer({ port: 9191 });
ws.on('connection', function(ws) {
  console.log('client connected');
  ws.send('您好，我是Robot客服001，请问您有什么问题？');
  console.log('hello is sent');
  
  ws.on('message', function(data, flag) {
    console.log(data);
    if (data.indexOf('再见') > -1) {
      ws.send('很高兴认识您。再见！');
      ws.send('此次会话将结束');
      console.log('bye is sent');
    } else {
      ws.send('对不起，目前我还无法理解您的意思。如果可以的话，请输入"再见"');
      console.log('cannot understand');
    }

  });

  ws.on('open', function() {
    console.log('socket is open');
  });

  ws.on('close', function() {
    console.log('socket is closed');
  })
})
